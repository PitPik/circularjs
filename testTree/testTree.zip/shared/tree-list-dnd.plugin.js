require([
  'circular',
  'toolbox',
  'data-provider',
  'animate-toggle',
], ({ Plugin }, { $create }, { getIcon, checkItem }, Animate) => Plugin({
  selector: 'treeDndPlugin',
  events: {
    dragstart: 'dragstart',
    dragenter: 'dragenter',
    dragleave: 'dragleave',
    dragover: 'dragover',
    drop: 'drop',
    dragend: 'dragend',
  },
}, class treeDndPlugin {
  constructor(elm, crInst, input) {
    this.tree = [];
    this.noHover = {};
    this.revealItem = null;
    input(this);
  
    this.hoverTimer = 0;
    this.hoverTime = 400;
    this.dragImage = $create('div', 'drag-ghost');
    this.dragImageIcon = this.dragImage.appendChild($create('div'));
    this.dragItem = {};
    this.hoveredItem = {};
    this.cursorItem = {};
    this.canDrop = false;
    this.methods = { up: 'insertBefore', mid: 'appendChild', down: 'insertAfter' };
    this.anim = new Animate({ speed: .3 });
  
    elm.appendChild(this.dragImage);
    this.crInst = crInst;
    this.listener = crInst.installEvent(null, 'tree-action', ({ detail }) => {
      if (detail.type === 'drag-start') {
        this.dragItem = detail.item;
      }
    });
  }

  dragstart(e, elm, item) {
    this.dragImageIcon.innerHTML = `<em class="material-icons icon">${
      getIcon(item.kind)}</em> ${item.properties.title}`;
    e.dataTransfer.setData('text', item.name);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setDragImage(this.dragImage, -5, -5);

    item.class = 'is-dragging';
    this.noHover.toggle = true;
    this.crInst.triggerEvent('tree-action', { type: 'drag-start', item });
  }

  dragenter(e, elm, item) {
    this.cursorItem.linkClass = '';
    this.cursorItem = item;
    this.hoveredItem.hovered = false;
    this.hoveredItem = item;
    item.hovered = true;
    if (!item.elements) return; // Hmmm..

    this.canDrop = !this.dragItem.elements.element
      .contains(item.elements.element);
    this.openOnHover(item, !this.canDrop);
  }

  dragleave(e, elm, item) {}

  dragover(e, elm, item) {
    if (!this.canDrop || !item.views) return; // Hmmm..
    e.preventDefault();

    const cursor = item.views.link || item.elements.element;
    const pos = this.getPosition(e, cursor, item.kind === 'container');
    if (item.linkClass !== pos) {
      item.linkClass = pos;
    }
  }

  drop(e, elm, item) {
    if (!item.linkClass) return;
    const dragItem = checkItem(this.dragItem, this.tree);
    this.tree[this.methods[item.linkClass]](dragItem, item);

    this.revealItem(dragItem, true);
    this.anim.animateDrop(dragItem.views.link, [0, 87, 163]);
    this.cleanup(); // if from other source
  }

  dragend(e, elm, item) {
    item.class = '';
    this.cleanup();
    this.crInst.triggerEvent('tree-action', {
      type: 'drag-end',
      item,
    });
  }

  cleanup() {
    clearTimeout(this.hoverTimer);
    this.cursorItem.linkClass = '';
    this.hoveredItem.hovered = false;
    this.noHover.toggle = false;
  }

  openOnHover(item, containsItem) {
    clearTimeout(this.hoverTimer);
    if (
      !item.childNodes ||
      item.childNodes.length === 0 ||
      item.isOpen ||
      containsItem
    ) return;
  
    this.hoverTimer = setTimeout(() => item.isOpen = true, this.hoverTime);
  }

  getPosition(e, elm, inside) {
    const top = elm.offsetHeight / (inside ? 3.5 : 2);
    const bottom = top * (inside ? 2.5 : .5);

    return e.offsetY <= top ? 'up' : e.offsetY >= bottom ? 'down' : 'mid';
  }

}));