define('animate-toggle', ['animate'], Animate => {
  Animate.prototype.toggle = function(element, currentState, speed, itemElement) {
    const value = element.scrollHeight;
    const isOpen = !currentState;
    const start = isOpen ? value : 0;
    const end = isOpen ? 0 : value;
    const fn = () => isOpen ? 0 : element.scrollHeight;
    const css = `height: ${start}px -> ${(start < end ? 'fn|fn' : end)}`;

    this.queue(element, css, speed, {
      endCallback: elm => elm.style.height = '',
      updateCallbacks: { fn },
    });
    clearTimeout(this.toggle._timer);
    this.toggle._timer = setTimeout(() => this.resetAnimation(element));
    setTimeout(() => itemElement.classList[!isOpen ? 'add' : 'remove']('is-open'), 10);
  };

  Animate.prototype.animateDrop = function(element, colors, alpha) {
    element.style.color = '';
    const color = window.getComputedStyle(element).getPropertyValue('color');
    const rgb = color.replace(/[rgbahsl()]/g, '').split(/\s*,\s*/);
    const css = `color: rgba(${
      colors[0]} => ${rgb[0]}, ${colors[1]} => ${rgb[1]}, ${colors[2]} => ${rgb[2]}, ${
      alpha && alpha[0] || '0.8'} -> ${alpha && alpha[1] || '0.8'})`;
    this.animate(element, css, 1, { endCallback: (elm) => elm.style.color = '' }, n => n * n);
  }

  return Animate;
});
