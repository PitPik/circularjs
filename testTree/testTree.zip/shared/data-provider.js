define('data-provider', ['toolbox'], ({ ajax, storageHelper, keys }) => {
  const getTreePath = key => ({
    tree: 'mock-data/page-model.json',
    catalog: 'mock-data/catalog.json',
  }[key]);
  const storageData = {}; // TODO: store open items...
  const syncStore = {};
  let isSyncing = false;
  const mapTreeModel = (model, isNew, storageName, recursion) => {
    if (!recursion && storageName) {
      storageData[storageName] = storageData[storageName] || [];
      storageData[storageName] = provider.fetchToggles(storageName);
    }

    return model.map(item => ({
      ...item,
      childNodes: mapTreeModel(item.children || [], isNew, storageName, true),
      // extra items for view
      isOpen: (storageData[storageName] || []).indexOf(item.name) !== -1,
      hovered: false,
      selected: false,
      active: false,
      name: item.name.replace('_new', '') + (isNew ? '_new' : ''), // demo
      class: '',
      linkClass: '',
      title: item.properties && item.properties.title,
      draggable: true, // all for now; needs rules
      isHidden: false,
    }));
  };
  const getIcon = kind => ({ // TODO: move to more generic service
    addAfter: 'playlist_add',
    addBefore: 'playlist_add',
    addInside: 'playlist_add',
    close: 'close',
    closeInner: 'unfold_less',
    container: 'video_label',
    delete: 'delete',
    properties: 'settings',
    tree: 'subject',
    page: 'subject', // TODO: re-think...
    widget: 'apps',
    catalog: 'storage',
    portals: 'dashboard',
    links: 'note',
    content: 'image',
    upload: 'cloud_upload',
  })[kind] || 'apps';

  const provider = {
    getTree: (type) => ajax(getTreePath(type), { dataType: 'json', cache: 300 })
      .then(data => {
        return mapTreeModel(type === 'tree' ? [data.children[0]] : data, false, type);
      }),
    checkItem: (item, model) => {
      const isOwnItem = provider.getItem(item, model);
      return isOwnItem || mapTreeModel([model.getCleanModel(item)], !isOwnItem)[0];
    },
    getItem: (item, model) => {
      return model.getElementsByProperty('name', item.name)[0];
    },
    getProperties: item => keys(item.properties)
      .reduce((acc, key) => acc.concat({ key, value: item.properties[key] }), []),
    fetchToggles: (name) => {
      return name ? storageHelper.fetch(name) || [] : [];
    },
    registerStore: (name, model) => {
      syncStore[name] = model;
    },
    syncModel: (crInst, name, prop, item, value, moved) => {
      if (isSyncing) return;
      isSyncing = true;

      keys(syncStore).forEach(key => {
        if (key === name) return;
        const api = syncStore[key];
        const currentItem = provider.checkItem(item, api);

        if (prop === 'parentNode') {
          // ...
        } else if (moved) {
          if (!currentItem) return;
          const sibling = prop === 'insertBefore' ? item.parentNode.childNodes[item.index + 1] :
            prop === 'insertAfter' ? item.parentNode.childNodes[item.index - 1] : null;
          const currentParent = value && provider.getItem(value, api);
          if (currentItem === currentParent && prop !== 'removeChild') return;
          const currentSbling = sibling && provider.getItem(sibling, api);
          if (!currentSbling && !currentParent && prop !== 'removeChild') return;
          if (prop === 'removeChild' && !provider.getItem(item, api)) return;
          api[prop](currentItem, currentSbling || currentParent);
        } else if (currentItem) {
          if (currentItem['cr-id']) {
            currentItem[prop] = value;
          } else {
            // ...
          }
        }
      });
      if (prop === 'active' || prop === 'removeChild') {
        const someStore = syncStore[keys(syncStore)[0]];
        someStore && crInst.publish(null, 'tree-action', 'change', {
          type: prop,
          item: provider.getItem(item, someStore) || item,
          value,
          source: name
        });
      }
  
      isSyncing = false;
    },
    storeToggle: (item, name) => {
      if (!name) return;
      const data = storageData[name] || [];
      if (item.isOpen === true) {
        if (data.indexOf(item.name) === -1) {
          data.push(item.name);
        }
      } else {
        const index = data.indexOf(item.name);
        index !== - 1 && data.splice(index, 1);
      }
      storageHelper.saveLazy(data, name, provider);
    },
    i18n: input => input.trim(), // TODO: implement if needed
    getIcon: getIcon, // TODO: move to more generic service
    actions: { // TODO: move to more generic service
      closeTab: {
        event: 'triggerEvent',
        title: 'Close',
        aIcon: getIcon('close'),
      },
      showTree: {
        event: 'triggerEvent',
        title: 'Toggle tree pane',
        aIcon: getIcon('tree'),
      },
      showProperties: {
        event: 'triggerEvent',
        title: 'Toggle properties pane',
        aIcon: getIcon('properties'),
      },
      // ................
      deleteItem: {
        event: 'deleteItem',
        title: 'Delete',
        aIcon: getIcon('delete'),
      },
      addItemBefore: {
        event: 'addItemBefore',
        title: 'Add before',
        aIcon: getIcon('addBefore'),
        class: 'flip',
      },
      addItemAfter: {
        event: 'addItemAfter',
        title: 'Add after',
        aIcon: getIcon('addAfter'),
      },
      addItemInside: {
        event: 'addItemInside',
        title: 'Create folder inside',
        aIcon: getIcon('addInside'),
      },
      // ................
      closeInnerFolders: {
        event: 'closeInnerFolders',
        title: 'Close inner folders',
        aIcon: getIcon('closeInner'),
      },
    },
  };

  return provider;
});
