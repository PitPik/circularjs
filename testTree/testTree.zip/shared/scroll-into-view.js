define('', [], function() { 'use strict';

  var ScrollIntoView = function (options) {
    this.options = {
      speed: .5,
      delay: .05,
      ease: function(n) { return -(--n * n * n * n - 1) },
      offset: [12, 12], // TODO: horiz. scroll
    };
    for (var option in options) this.options[option] = options[option];
    this.item = { scope: null, animation: null, dalay: null };
  };

  var win = window;
  var animate = win.requestAnimationFrame ||
    win.webkitRequestAnimationFrame ||
    function(cb) { return win.setTimeout(cb, 16) };
  var cancelAnim = win.cancelAnimationFrame ||
    win.webkitCancelAnimationFrame ||
    function(timer) { return win.clearTimeout(timer) };

  ScrollIntoView.prototype = {
    scroll: function(elm, scope, speed, ease, force) {
      var _this = this;
      var item = this.item;

      if (item.scope && item.scope === scope) win.clearTimeout(item.delay);
      item.delay = win.setTimeout(function() {
        var visData = checkVisibility(elm, scope, _this.options.offset);

        if (!force && (visData.exceedsBoundaries || visData.isInside)) return;
        if (item.scope && item.scope === scope) cancelAnim(item.animation);
        item.scope = scope;
        item.animation = animate(function() {
          scroll(_this, {
            scope: scope,
            delta: visData.scrollDelta,
            time: Date.now(),
            duration: (speed !== undefined ? speed : _this.options.speed) * 1000,
            ease: ease || _this.options.ease,
            scrollTop: scope.scrollTop,
            xAxis: scope.scrollLeft
          });
        });
      }, this.options.delay * 1000);
    },
  };

  return ScrollIntoView;

  function checkVisibility(elm, scope, offset) {
    var elmDims = elm.getBoundingClientRect();
    var scopeDims = scope.getBoundingClientRect();
    var top = elmDims.top - scopeDims.top - offset[1];
    var bottom = scopeDims.bottom - elmDims.bottom - offset[1];
    var exceedsBoundaries = scopeDims.height < elmDims.height;
    var isInside = !exceedsBoundaries && (bottom > 0 && top > 0) ||
        exceedsBoundaries && (bottom > 0 || top > 0);

    return {
      exceedsBoundaries: exceedsBoundaries,
      isInside: isInside,
      scrollDelta: isInside ? 0 : bottom < 0 ? -bottom : top < 0 ? top : 0,
    };
  }

  function scroll(_this, data) {
    var diff = data.duration ? (Date.now() - data.time) / data.duration : 1;
    var isDone = diff >= 1;

    data.scope.scrollTo(data.xAxis, data.scrollTop +
      (isDone ? data.delta : data.ease(diff) * data.delta));

    if (isDone) {
      _this.item = {};
    } else {
      _this.item.animation = animate(function() { scroll(_this, data) });
    }
  }
});