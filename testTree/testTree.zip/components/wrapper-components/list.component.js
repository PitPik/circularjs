require(['circular', 'tree-list'],
({ Component }) => Component({
  selector: 'list',
  template: `
    <tree-list
      cr-cloak
      cr-input="'false' as isOpen, 'true' as hasActions, 'Catalog items' as name, 'catalog' as data, 'list' as type"
      cr-plugin="treeDndPlugin: tree, noHover, revealItem"
    >
      <component-header class="toolbox" cr-input="name, 'catalog' as icon, 'left-main' as close"></component-header>
      <list-tool-bar class="list-tool-bar" cr-input="name, treeToggle, tree, revealItem, activeItem"></list-tool-bar>
    </tree-list>`,
  styles: 'tree { height: 100% }',
}, class List {}));
