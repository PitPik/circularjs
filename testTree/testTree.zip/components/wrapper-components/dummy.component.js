require(['circular'],
({ Component }, tree) => Component({
  selector: 'dummy',
  styles: 'dummy { background: #2b2b2b; }',
}, class Dummy {}));
