require(['circular'],
({ Component }, tree) => Component({
  selector: 'dummy',
  styles: 'dummy { background: #262626; }',
}, class Dummy {
  constructor(elm, crInst, input) {
    this.buttons = '';
    input(this);
  }
}));
