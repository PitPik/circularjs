require(['circular'],
({ Component }, tree) => Component({
  selector: 'proeprties',
  styles: 'proeprties { background: #2b2b2b; }',
}, class Proeprties {}));
