require(['circular', 'properties-ui.component'],
({ Component }, tree) => Component({
  selector: 'properties',
  template: `
    <properties-ui class="flex-col">
      <component-header class="toolbox" cr-input="'Properties' as name, 'properties' as icon"></component-header>
      <div class="context-menu toolbox extra" style="background: #333333;">Place holder</div>
    </properties-ui>`,
  styles: 'properties { display: block; height: 100% } properties-ui { height: 100%; }',
}, class Proeprties {}));
