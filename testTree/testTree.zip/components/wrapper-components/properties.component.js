require(['circular', 'properties-ui.component', 'properties-toolbar.component'],
({ Component }, tree) => Component({
  selector: 'properties',
  template: `
    <properties-ui class="flex-col">
      <component-header class="toolbox" cr-input="'Properties' as name, 'properties' as icon"></component-header>
      <properties-toolbar class="context-menu toolbox"></properties-toolbar>
    </properties-ui>`,
  styles: 'properties { display: block; height: 100% } properties-ui { height: 100%; }',
}, class Proeprties {}));
