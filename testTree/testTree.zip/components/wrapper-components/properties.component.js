require(['circular', 'properties-ui.component'],
({ Component }, tree) => Component({
  selector: 'properties',
  template: `
    <div class="flex-col">
      <component-header class="toolbox" cr-input="'Properties' as name, 'properties' as icon"></component-header>
      <properties-ui class="flex-col"></properties-ui>
    </div>`,
  styles: 'properties { height: 100% }',
}, class Proeprties {}));
