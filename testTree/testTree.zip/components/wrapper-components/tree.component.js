require(['circular', 'tree-list'],
({ Component }) => Component({
  selector: 'tree',
  template: `
    <tree-list
      cr-cloak
      cr-input="'false' as isOpen, 'true' as hasActions, 'Page items' as name, 'tree' as data"
      cr-plugin="treeDndPlugin: tree, noHover, revealItem"
    >
      <component-header class="toolbox" cr-input="name, 'tree' as icon"></component-header>
      <tool-bar class="tool-bar" cr-input="name, treeToggle, tree, revealItem, activeItem"></tool-bar>
    </tree-list>`,
  styles: 'tree { height: 100% }',
}, class Tree {}));
