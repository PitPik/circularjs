require([
  'circular',
  'data-provider',
], ({ Component }, { getIcon }) => Component({
  selector: 'properties-toolbar',
  template: `
    <span class="description">
      {{#if %title}}
        <i class="material-icons" title="From: {{%sourceTitle}}">{{%sourceIcon}}</i>-
        <i class="material-icons" title="Item type: {{%itemTitle}}">{{%itemIcon}}</i>:
        <span title="Item title: {{title}}">{{title}}</span>
      {{else}}
        &nbsp;
      {{/if}}
    </span>`,
  styles: `properties-toolbar { background: #333333; } .description { margin-left: 0; }`,
  subscribe$: { this : ['title', 'sourceIcon', 'itemIcon', 'itemTitle', 'sourceTitle'] },
}, class PropertiesToolbar {
  constructor(elm, crInst, input) {
    this.title = '';
    this.itemIcon = '';
    this.sourceIcon = '';
    this.itemTitle = '';
    this.sourceTitle = '';

    crInst.subscribe(null, 'tree-action', 'change', data => {
      if (data.type !== 'active') {
        this.title = '';
        return;
      }
      if (!data.value) return;

      this.title = data.item.title;
      const source = data.source === 'list' ? 'catalog': 'tree';
      this.sourceIcon = getIcon(source);
      this.sourceTitle = source;
      this.itemIcon = getIcon(data.item.kind);
      this.itemTitle = data.item.kind;
    }, true);
  }
}));
