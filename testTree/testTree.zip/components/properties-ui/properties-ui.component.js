require(['circular', '!properties-ui.component.html', '!properties-ui.component.css', 'tree-list-helper'],
({ Component }, template, styles) => Component({
  selector: 'properties-ui',
  template,
  styles,
  subscribe$: { this : ['noItems', 'properties'], properties: ['title'] },
}, class PropertiesUi {
  constructor(elm, crInst, input) {
    this.noItems = true;
    this.properties = [];
  }

  properties$$() {
    this.noItems = !this.properties.length;
  }

  onInit() {
    this.properties = [ // TODO: async in constructor
      { title: 'Description' },
      { title: 'Title' },
      { title: 'area' },
    ];
  }

  toggleDetails(e, elm, item) {
    e.preventDefault();
    item.views.details.classList.toggle('closed');
  }

}));
