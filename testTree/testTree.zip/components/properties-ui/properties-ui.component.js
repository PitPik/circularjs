require([
  'circular',
  'data-provider',
  '!properties-ui.component.html',
  '!properties-ui.component.css',
  'tree-list-helper'
], ({ Component }, { getProperties }, template, styles) => Component({
  selector: 'properties-ui',
  template,
  styles,
  subscribe$: { this : ['noItems'], properties: ['key', 'value'] },
}, class PropertiesUi {
  constructor(elm, crInst, input) {
    this.noItems = true;
    this.properties = [];

    crInst.subscribe(null, 'tree-action', 'change', data => {
      if (data.type === 'active' && data.value === false) return;
      this.properties = data.type === 'removeChild' ? [] : getProperties(data.item);
      this.noItems = !this.properties.length;
    }, true);
  }

  toggleDetails(e, elm, item) {
    e.preventDefault();
    item.views.details.classList.toggle('closed');
  }
}));
