require([
  'circular',
  '!tree-list.html',
  '!tree-list.css',
  'tree-list-helper',
  'data-provider',
  'animate-toggle',
  'scroll-into-view',
  'tree-list-dnd',
  'component-header',
  'tree-list-actions',
  'tree-tool-bar',
], ({ Component }, template, styles, getHelpers, dataProvider, Animate, Scroll) => Component({
  selector: 'tree-list',
  template,
  styles,
  helpers: getHelpers(),
  subscribe$: {
    this: ['activeItem', 'noItems'],
    tree: ['title', 'isOpen', 'hovered', 'selected', 'active', 'linkClass', 'class', 'isHidden'],
  },
}, class TreeList {
  constructor(elm, crInst, input) {
    this.isOpen = false;
    this.hasActions = false;
    this.data = '';
    this.name = 'the-tree';
    this.type = '';
    this.oneActive = true;
    input(this);
    this.tree = [];
    this.noItems = true;
    this.noHover = { toggle: false };
    this.activeItem = null;
    this.anim = new Animate({ speed: .3 });
    this.scroller = new Scroll();
    this.treeRootContainer;
    this.crInst = crInst;

    dataProvider.getTree(this.data).then(data => {
      this.tree = data;
      if (!data[0].isOpen) this.treeToggle(this.isOpen);
      dataProvider.registerStore(this.data, this.tree);
    });
    crInst.subscribe(null, 'tree-action', 'change', data => { // TODO: dataProv.?
      if (data.type !== 'active') return;
      if (!dataProvider.getItem(data.item, this.tree) && this.oneActive) {
        (this.activeItem || {}).active = false;
      }
    });
  }

  onInit(elm, crInst, items) {
    this.treeRootContainer = items.views.root;
  }

  tree$(prop, item, value, oldValue) {
    if (value === oldValue) return;
    if (prop === 'active') {
      (this.activeItem || {}).active = false;
      this.activeItem = value ? item : null;
    } else if (prop === 'isOpen') {
      dataProvider.storeToggle(item, this.data);
      const elms = item.elements;
      this.anim.toggle(elms.container, value, undefined, elms.element);
    }
    if (value && (this.noHover.toggle || prop === 'active' || prop === 'selected')) {
      this.revealItem(item); // TODO: rethink (drop...)
    }
  }

  tree$$(prop, item, value, oldValue, moved) {
    this.type !== 'list' && // TODO...
      dataProvider.syncModel(this.crInst, this.data, prop, item, value, moved);
    if (!moved) return;
    this.noItems = !this.tree.length;
    if (prop === 'removeChild' && item === this.activeItem) {
      this.activeItem = null;
    } else if (oldValue && oldValue.childNodes.length === 0) {
      setTimeout(() => oldValue.isOpen = false);
    }
  }

  treeToggle(toggle) {
    const leaveOpen = {};
    let leaf = this.tree.length === 1 && !toggle && this.tree[0] || {};

    while (leaf.childNodes && leaf.childNodes.length === 1) {
      leaveOpen[leaf['cr-id']] = leaf.isOpen = true;
      leaf = leaf.childNodes[0];
    }
    leaf.isOpen = true;
    this.tree.getElementsByProperty('isOpen', !toggle).forEach(item => {
      if (
        leaveOpen[item['cr-id']] === true ||
        leaveOpen[item.parentNode['cr-id']] === true ||
        item.childNodes === undefined ||
        item.childNodes[0] === undefined
      ) return;
      item.isOpen = toggle;
    });
  }

  revealItem(item, scroll) {
    const link = item && item.views.link;
    while (item && (item = item.parentNode)) if (!item.isOpen) item.isOpen = true;
    scroll && link && this.scroller.scroll(link, this.treeRootContainer);
  }

  hover(e, elm, item) {
    return e.target === elm && !this.noHover.toggle ?
      item.hovered = true : null;
  }

  blur(e, elm, item) {
    return e.target === elm ? item.hovered = false : null;
  }

  select(e, elm, item) {
    item.active = true;
  }

  toggle(e, elm, item) {
    e.preventDefault();
    item.isOpen = !item.isOpen;
    return false;
  }

  preventDblclick(e) {
    return false;
  }

  dblclick(e, elm, item) {
    this.crInst.triggerEvent('tree-action', {
      type: 'dblclick',
      name: this.data,
      item: item,
      value: true,
    });
  }
}));
