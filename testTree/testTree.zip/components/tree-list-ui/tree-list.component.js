require([
  'circular',
  '!tree-list.html',
  '!tree-list.css',
  'tree-list-helper',
  'data-provider',
  'animate-toggle',
  'scroll-into-view',
  'tree-list-dnd',
  'module-header',
  'tree-list-actions',
  'tool-bar',
], ({ Module }, template, styles, getHelpers, dataProvider, Animate, Scroll) => Module({
  selector: 'tree-list',
  template,
  styles,
  helpers: getHelpers(),
  subscribe$: {
    this: ['activeItem'],
    tree: ['title', 'isOpen', 'hovered', 'selected', 'active', 'linkClass', 'class'],
  },
}, class TreeList {
  tree = [];
  isOpen = false;
  hasActions = false;
  name = 'the-tree';
  noHover = { toggle: false };
  activeItem = {};
  anim = new Animate({ speed: .3 });
  scroller = new Scroll();
  treeRootContainer;

  constructor(elm, crInst, input) {
    input(this);
    dataProvider.getTree(this.name).then(data => {
      this.tree = data;
      if (!data[0].isOpen) {
        this.treeToggle(this.isOpen);
      }
    });
  }

  onInit(elm, crInst, items) {
    this.treeRootContainer = items.views.root;
  }

  tree$(prop, item, value, oldValue) {
    if (value === oldValue) return;
    if (prop === 'active') {
      this.activeItem.active = false;
      this.activeItem = item;
    } else if (prop === 'isOpen') {
      dataProvider.storeToggle(item, this.name);
      const elms = item.elements;
      this.anim.toggle(elms.container, value, undefined, elms.element);
    }
    if (value && prop.match(/active|selected|hovered/)) {
      this.revealItem(item);
    }
  }

  tree$$(prop, item, value, oldValue, moved) {
    if (!moved) return;
    if (oldValue && oldValue['cr-id']) {
      this.anim.animateDrop(item.views.link, [0, 87, 163]);
      this.scroller.scroll(item.views.link, this.treeRootContainer);
    } else if (item === this.activeItem) {
      this.activeItem = {};
    }
  }

  treeToggle(toggle) {
    const leaveOpen = {};
    let leaf = this.tree.length === 1 && !toggle && this.tree[0] || {};

    while (leaf.childNodes && leaf.childNodes.length === 1) {
      leaveOpen[leaf['cr-id']] = leaf.isOpen = true;
      leaf = leaf.childNodes[0];
    }
    leaf.isOpen = true;
    this.tree.getElementsByProperty('isOpen', !toggle).forEach(item => {
      if (
        leaveOpen[item['cr-id']] === true ||
        leaveOpen[item.parentNode['cr-id']] === true ||
        item.childNodes === undefined ||
        item.childNodes[0] === undefined
      ) return;
      item.isOpen = toggle;
    });
  }

  revealItem(item, scroll) {
    const link = item && item.views.link;
    while (item && (item = item.parentNode)) if (!item.isOpen) item.isOpen = true;
    scroll && link && this.scroller.scroll(link, this.treeRootContainer);
  }

  hover(e, elm, item) {
    return e.target === elm && !this.noHover.toggle ?
      item.hovered = true : null;
  }

  blur(e, elm, item) {
    return e.target === elm ? item.hovered = false : null;
  }

  select(e, elm, item) {
    item.active = true;
  }

  toggle(e, elm, item) {
    e.preventDefault();
    return item.isOpen = !item.isOpen, false;
  }
}));
