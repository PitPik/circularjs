require([
  'circular',
  '!tree-list.html',
  '!tree-list.css',
  'tree-list-helper',
  'data-provider',
  'animate-toggle',
  'scroll-into-view',
  'tree-list-dnd',
  'component-header',
  'tree-list-actions',
  'tree-tool-bar',
], ({ Component }, template, styles, getHelpers, dataProvider, Animate, Scroll) => Component({
  selector: 'tree-list',
  template,
  styles,
  helpers: getHelpers(),
  subscribe$: {
    this: ['activeItem', 'noItems'],
    tree: ['title', 'isOpen', 'hovered', 'selected', 'active', 'linkClass', 'class', 'isHidden'],
  },
}, class TreeList {
  constructor(elm, crInst, input) {
    this.isOpen = false;
    this.hasActions = false;
    this.data = '';
    this.name = 'the-tree';
    this.type = '';
    this.oneActive = true;
    input(this);
    this.tree = [];
    this.noItems = true;
    this.noHover = { toggle: false };
    this.activeItem = null;
    this.anim = new Animate({ speed: .3 });
    this.scroller = new Scroll();
    this.treeRootContainer;
    this.crInst = crInst;
    this.isListening = false;
    this.destroyEvent =
      crInst.installEvent(null, 'tree-action', this.actionListener.bind(this));

    dataProvider.getTree(this.data).then(data => {
      this.tree = data;
      if (!data[0].isOpen) {
        this.treeToggle(this.isOpen);
      }
    });
  }

  onInit(elm, crInst, items) {
    this.treeRootContainer = items.views.root;
  }

  onDestroy() {
    this.destroyEvent();
  }

  tree$(prop, item, value, oldValue) {
    if (value === oldValue) return;
    if (prop === 'active') {
      (this.activeItem || {}).active = false;
      this.activeItem = value ? item : null;
    } else if (prop === 'isOpen') {
      dataProvider.storeToggle(item, this.data);
      const elms = item.elements;
      this.anim.toggle(elms.container, value, undefined, elms.element);
    }
  }

  tree$$(prop, item, value, oldValue, moved) {
    this.noItems = !this.tree.length;
    if (prop.match(/active|selected|hovered/) || prop === 'removeChild') { //value && 
      if (value && (this.noHover.toggle || prop === 'active' || prop === 'selected')) {
        this.revealItem(item); //, this.isListening
      }
      !this.isListening && this.crInst.triggerEvent('tree-action', {
        type: prop,
        name: this.data,
        item,
        value,
        source: this.type,
      });
    }
    if (!moved) return;
    if (prop === 'removeChild' && item === this.activeItem) {
      this.activeItem = null;
    } else if (oldValue && oldValue.childNodes.length === 0) {
      setTimeout(() => oldValue.isOpen = false);
    }
  }

  actionListener({ detail }) {
    if (detail.name === this.data) return;
    this.isListening = true;
    const item = dataProvider.getItem(detail.item, this.tree);
    if (item) {
      item[detail.type] = detail.value;
    } else if (detail.type === 'active' && this.activeItem && this.oneActive) {
      this.activeItem.active = false;
      this.activeItem = null;
    }
    this.isListening = false;
  }

  treeToggle(toggle) {
    const leaveOpen = {};
    let leaf = this.tree.length === 1 && !toggle && this.tree[0] || {};

    while (leaf.childNodes && leaf.childNodes.length === 1) {
      leaveOpen[leaf['cr-id']] = leaf.isOpen = true;
      leaf = leaf.childNodes[0];
    }
    leaf.isOpen = true;
    this.tree.getElementsByProperty('isOpen', !toggle).forEach(item => {
      if (
        leaveOpen[item['cr-id']] === true ||
        leaveOpen[item.parentNode['cr-id']] === true ||
        item.childNodes === undefined ||
        item.childNodes[0] === undefined
      ) return;
      item.isOpen = toggle;
    });
  }

  revealItem(item, scroll) {
    const link = item && item.views.link;
    while (item && (item = item.parentNode)) if (!item.isOpen) item.isOpen = true;
    scroll && link && this.scroller.scroll(link, this.treeRootContainer);
  }

  hover(e, elm, item) {
    return e.target === elm && !this.noHover.toggle ?
      item.hovered = true : null;
  }

  blur(e, elm, item) {
    return e.target === elm ? item.hovered = false : null;
  }

  select(e, elm, item) {
    item.active = true;
  }

  toggle(e, elm, item) {
    e.preventDefault();
    item.isOpen = !item.isOpen;
    return false;
  }

  preventDblclick(e) {
    return false;
  }

  dblclick(e, elm, item) {
    this.crInst.triggerEvent('tree-action', {
      type: 'dblclick',
      name: this.data,
      item: item,
      value: true,
    });
  }
}));
