require(['circular', '!list-tool-bar.html', '!list-tool-bar.css', 'tree-list-helper'],
({ Component }, template, styles, getHelpers) => Component({
  selector: 'list-tool-bar',
  template,
  styles,
  helpers: getHelpers(['i18n']),
  subscribe$: { this: ['searchValue'] },
}, class ListToolBar {
  constructor(elm, crInst, input) {
    this.name = '';
    this.treeToggle;
    this.revealItem;
    this.tree = [];
    this.activeItem = null;
    input(this);
    this.searchValue = '';
    this.foundItems = [];
  }

  this$(prop, item, value) {
    if (prop !== 'searchValue') return;
    const txt = value.trim().split(/\s+/).filter($1 => $1).join('))(?=.*(');
    const regExp = new RegExp(`(?=.*(${txt})).*`, 'i');
    this.foundItems.forEach(found => found.isHidden = false);
    this.foundItems = this.tree.getElementsByProperty(
      'properties.title',
      $1 => !$1.match(regExp)
    );
    this.foundItems.forEach(found => found.isHidden = true);
  }

  clear(e) {
    if (e.key === 'Escape') {
      this.searchValue = '';
    }
  }

  input(e) {
    this.searchValue = e.target.value;
  }

  clearInput() {
    this.searchValue = '';
    return false;
  }

  filter() {
    console.log('filter');
  }

  sort() {
    console.log('sort');
  }
 }));
