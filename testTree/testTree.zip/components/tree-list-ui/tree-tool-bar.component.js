require(['circular', '!tree-tool-bar.html', '!tree-tool-bar.css', 'tree-list-helper'],
({ Component }, template, styles, getHelpers) => Component({
  selector: 'tree-tool-bar',
  template,
  styles,
  helpers: getHelpers(['i18n']),
  subscribe$: { this: ['searchValue', 'counter', 'all', 'activeItem'] },
}, class TreeToolBar {
  constructor(elm, crInst, input) {
    this.name = '';
    this.treeToggle;
    this.revealItem;
    this.tree = [];
    this.activeItem = null;
    input(this);
    this.foundItems = [];
    this.debounce = 0;
    this.delay = 300;
    this.minsearch = 2;
    this.RegExp = {};
    this.counter = '';
    this.all = '';
    this.searchValue = '';
  }

  this$(prop) { // TODO: make 'search' its own component
    if (prop !== 'searchValue') return;

    clearTimeout(this.debounce);
    if (this.searchValue.length < this.minsearch) {
      this.counter = this.all = '';
      return this.mark(this.foundItems, false);
    }

    this.debounce = setTimeout(() => {
      if (!this.all) this.all = this.tree.getElementsByProperty().length + '';
      const found = this.getSearchResult(this.searchValue, this.tree);
      const diff = this.foundItems.filter(item => !found.includes(item));
      this.mark(diff, false);
      this.foundItems = this.mark(found, true);
      this.counter = found.length;
    }, this.delay);
  }

  mark(items, toggle) {
    items.forEach(item => {
      item.selected = toggle;
      item.title = !toggle ? item.properties.title : item.properties.title
        .replace(this.RegExp, (...args) => {
          args.slice(1, args.length - 2).forEach(finding =>
            args[0] = args[0].replace(finding, ($1 => `<b>${$1}</b>`))
          );
          return args[0];
        });
    });
    return items;
  }

  getSearchResult(searchValue, treeAPI) {
    const txt = searchValue.trim().split(/\s+/).filter($1 => $1).join('))(?=.*(');
    this.RegExp = new RegExp(`(?=.*(${txt})).*`, 'i');
    return searchValue === '' ? [] : treeAPI
      .getElementsByProperty('properties.title', $1 => $1.match(this.RegExp));
  }

  clear(e) {
    if (e.key === 'Escape') {
      this.searchValue = '';
    }
  }

  input(e) {
    this.searchValue = e.target.value;
  }

  blurInput() {
    this.searchValue = '';
  }

  expand() {
    this.treeToggle(true);
  }

  collapse() {
    this.treeToggle(false);
  }

  showActive() {
    this.revealItem(this.activeItem, true);
  }
 }));
