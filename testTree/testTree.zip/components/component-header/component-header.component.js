require(['circular', 'data-provider', 'tree-list-helper'],
({ Component }, { getIcon, actions }, getHelpers) => Component({
  selector: 'component-header',
  template: `
    <h2>
      <i class="material-icons" title="{{name}}">{{icon}}</i>{{i18n name}}
      <span class="pull-right">
        <i
          cr-for="actionModel"
          cr-event="click: {{event}}"
          class="material-icons"
          title="{{i18n title}}"
        >{{aIcon}}</i>
      </span>
    </h2>`,
  styles: `component-header { display: block; background: #333333; flex-shrink: 0!important; }`,
  helpers: getHelpers(['i18n']),
}, class ComponentHeader {
  constructor(elm, crInst, input) {
    this.name = '';
    this.icon = '';
    this.close = ''; // TODO: make cr-actions="closeMainLeft, showTree, ..."  
    input(this);
    this.icon = getIcon(this.icon);
    this.actionModel = this.buidModel([]);
    this.crInst = crInst;
  }

  buidModel(out) {
    out.push({
      ...actions.showTree,
    });
    out.push({
      ...actions.closeTab,
      title: `${actions.closeTab.title} ${this.name}`,
    });
    return out;
  }

  closeTab() {
    this.crInst.triggerEvent('close-tab', {
      name: this.name,
      type: this.close,
    });
  }

  showTree() {
    this.crInst.triggerEvent('show-tree', { name: this.name });
  }
}));