require(['circular', 'data-provider', 'tree-list-helper', 'toolbox'],
({ Component }, { getIcon, actions }, getHelpers, { closest }) => Component({
  selector: 'component-header',
  template: `
    <h2>
      <i class="material-icons" title="{{name}}">{{icon}}</i>{{i18n name}}
      <span class="pull-right">
        <i
          cr-for="actionModel"
          cr-event="click: {{%event}}"
          cr-action="{{%action}}"
          class="material-icons"
          title="{{%i18n title}}"
        >{{%aIcon}}</i>
      </span>
    </h2>`,
  styles: `component-header { display: block; background: #333333; flex-shrink: 0!important; }`,
  helpers: getHelpers(['i18n']),
  subscribe$: { actionModel: ['event', 'action', 'title', 'aIcon'] },
}, class ComponentHeader {
  constructor(elm, crInst, input) {
    this.name = '';
    this.icon = '';
    input(this);
    this.icon = getIcon(this.icon);
    this.actionModel = [];
    this.crInst = crInst;
    crInst.installEvent(null, 'header-buttons', ({ detail }) => {
      const parent = closest(elm, `[cr-id="${detail.parentId}"]`);
      if (!parent) return; // TODO: this is hacky...
      this.actionModel = this.buidModel([], detail.buttons);
    });
  }

  buidModel(out, buttons) {
    buttons.split(/\s*\|\s*/).forEach(item => {
      item && out.push({
        ...actions[item.replace(/-./g, ($1) => $1.substr(1).toUpperCase())],
        action: item,
        event: 'triggerEvent',
      });
    })
    return out;
  }

  triggerEvent(e, elm) {
    this.crInst.triggerEvent(elm.getAttribute('cr-action'), { name: this.name });
  }
}));