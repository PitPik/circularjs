require(['circular', 'tree-list-helper', 'data-provider'],
({ Component }, getHelpers, dataProvider) => Component({
  selector: 'bread-crumb',
  template: `
    <ul cr-view="scrollContainer" class="bread-crumb">
      {{#if %noItems}}No item selected{{/if}}
      <li
        cr-for="breadcrumb"
        class="crumble" cr-event="click: click; mouseleave: blur; mouseenter: hover;"
        title="{{%title}}"
      >
        <i class="material-icons">{{#if %kind}}{{icon}}{{/if}}</i>
        <span class="text">{{%title}}</span>
      </li>
    </ul>`,
  helpers: getHelpers(['icon']),
  subscribe$: { this: ['noItems'], breadcrumb: ['title', 'kind', 'active', 'hovered']}
}, class BreadCrumb {
  constructor(elm , crInst) {
    this.breadcrumb = [];
    this.noItems = true;
    this.crInst = crInst;
  }

  breadcrumb$(prop, item, value) {
    if (prop !== 'active' && prop !== 'hovered') return;
    if (prop === 'active') {
      item.hovered = false;
      this.reduceModel(item);
    }
    dataProvider.syncModel('breadcrumb', prop, item, value);
  }

  onInit(elm, crInst, items) {
    const scrollContainer = items.views.scrollContainer;
    crInst.subscribe(null, 'tree-action', 'change', data => {
      if (data.item[data.type] === false) return;
      this.breadcrumb = data.type === 'removeChild' ? [] : this.buildModel(data.item);
      this.noItems = !this.breadcrumb.length;
      scrollContainer.scrollLeft = scrollContainer.scrollWidth;
    }, true);
  }

  buildModel(item) {
    const result = [{ title: item.title, kind: item.kind, name: item.name }];
    while (item = item.parentNode) if (!item.childNodes.root) result.push({
      title: item.title,
      kind: item.kind,
      name: item.name,
      active: false,
      hovered: false,
    });
    return result.reverse();
  }

  reduceModel(item) {
    let last = this.breadcrumb[this.breadcrumb.length - 1];
    while (last.name !== item.name) {
      this.breadcrumb.removeChild(last);
      last = this.breadcrumb[this.breadcrumb.length - 1];
    }
  }

  click(e, elm, item) {
    item.active = true;
  }

  hover(e, elm, item) {
    if (e.target !== elm) return;
    item.hovered = true;
  }

  blur(e, elm, item) {
    if (e.target !== elm) return;
    item.hovered = false;
  }
}));