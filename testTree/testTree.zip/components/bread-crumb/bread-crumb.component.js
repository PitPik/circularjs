require(['circular', 'tree-list-helper'],
({ Component }, getHelpers) => Component({
  selector: 'bread-crumb',
  template: `
    <ul cr-view="scrollContainer" class="bread-crumb">
      {{#unless %noItems}}No item selected{{/unless}}
      <li
        cr-for="breadcrumb"
        class="crumble" cr-event="click: click; mouseleave: blur; mouseover: hover;"
        title="{{%title}}"
      >
        <i class="material-icons">{{#if %kind}}{{icon}}{{/if}}</i>
        <span class="text">{{%title}}</span>
      </li>
    </ul>`,
  helpers: getHelpers(['icon']),
  subscribe$: { this: ['noItems'], breadcrumb: ['title', 'kind']}
}, class BreadCrumb {
  constructor(elm , crInst) {
    this.breadcrumb = [];
    this.noItems = false;
    this.uninstall = null;
    this.crInst = crInst;
  }

  onInit(elm, crInst, items) {
    const scrollContainer = items.views.scrollContainer;

    this.uninstall = crInst.installEvent(null, 'tree-action', ({ detail }) => {
      if (detail.type === 'active') {
        this.noItems = !!detail.item;
        let item = detail.item;
        if (detail.name === 'breadcrumbs') { // hacky
          let last = this.breadcrumb[this.breadcrumb.length - 1];
          while(last.name !== item.name) {
            this.breadcrumb.removeChild(last);
            last = this.breadcrumb[this.breadcrumb.length - 1];
          }
          return;
        }
        const result = [{ title: item.title, kind: item.kind, name: item.name }];

        while (item = item.parentNode) result.push({
          title: item.title,
          kind: item.kind,
          name: item.name,
        });

        this.breadcrumb = result.reverse();
        scrollContainer.scrollLeft = scrollContainer.scrollWidth;
      }
    });
  }

  onDestroy() {
    this.uninstall();
  }

  triggerEvent(type, item, value) {
    this.crInst.triggerEvent('tree-action', { type,
      name: this.data,
      item,
      value,
      name: 'breadcrumbs'
    });
  }

  click(e, elm, item) {
    this.triggerEvent('active', item, true);
  }

  hover(e, elm, item) {
    this.triggerEvent('hovered', item, true);
  }

  blur(e, elm, item) {
    this.triggerEvent('hovered', item, false);
  }
}));