require(['circular', 'tree-list-helper'],
({ Component }, getHelpers) => Component({
  selector: 'bread-crumb',
  template: `
    <ul cr-view="scrollContainer" class="bread-crumb">
      {{#unless %noItems}}No item selected{{/unless}}
      <li
        cr-for="breadcrumb"
        class="crumble" cr-event="click: click; mouseleave: blur; mouseover: hover;"
        title="{{%title}}"
      >
        <i class="material-icons">{{#if %kind}}{{icon}}{{/if}}</i>
        <span class="text">{{%title}}</span>
      </li>
    </ul>`,
  helpers: getHelpers(['icon']),
  subscribe$: { this: ['noItems'], breadcrumb: ['title', 'kind']}
}, class BreadCrumb {
  constructor() {
    this.breadcrumb = [];
    this.noItems = false;
    this.listener = null;
  }

  onInit(elm, crInst, items) {
    const scrollContainer = items.views.scrollContainer;

    this.listener = crInst.installEvent(null, 'tree-action', (e) => {
      if (e.detail.type === 'active') {
        this.noItems = !!e.detail.data;
        let item = e.detail.data;
        const result = [{ title: item.title, kind: item.kind }];

        while (item = item.parentNode) result.push({
          title: item.title,
          kind: item.kind,
        });

        this.breadcrumb = result.reverse();
        scrollContainer.scrollLeft = scrollContainer.scrollWidth;
      }
    });
  }

  onDestroy() {
    this.listener();
  }

  click(e, elm, item) {
    // uiStore.model.activeItem = item.name,
  }

  hover(e, elm, item) {
    // uiStore.model.hoveredTreeItem = item.name,
  }

  blur(e, elm, item) {
    // uiStore.model.hoveredTreeItem = '',
  }
}));