require(['circular', 'toolbox'],
({ Component }, { toggleClass, $ }) => Component({
  selector: 'tab-container',
  styles: `
    tab-container { flex-grow: 0!important; overflow: visible!important; }
    [cr-view="outlet"] { height: 100%; }`,
  subscribe$: { this : ['activeTab', 'activeApp'] },
}, class TabContainer {
  constructor(elm, crInst, input) {
    this.type = '';
    this.context = '';
    input(this);
    this.activeApp = null;
    this.activeTab = null;
    this.restoreTab = null;
    this.outletElm;
    this.rootElm;
    this.crInst = crInst;
    this.isCollapsible = this.type === 'collapsible';
    this.actions = [];
  }

  onInit(elm, crInst, items) {
    this.outletElm = items.views.outlet;
    this.rootElm = elm;
    if (!this.isCollapsible) {
      this.activeTab = items.views.tabsContainer.firstElementChild;
    }

    const nested = $(elm.tagName.toLowerCase(), elm);
    crInst.getAttributeData(elm, 'cr-actions', (key, value, element) => {
      if (nested && nested.contains(element)) return;
      const valueType = value.split(/\s*\|\s*/);
      this.actions.push(crInst.installEvent(null, valueType[0], ({ detail }) => {
        if (valueType[1] && detail.type !== valueType[1]) return;
        this.triggerTab(element, key);
      }))
    });
  }

  onDestroy() {
    this.actions.forEach(action => action());
  }

  this$(prop, item, value, oldValue) {
    if (prop === 'activeTab') {
      toggleClass(oldValue, 'active', false);
      const appName = value.getAttribute('cr-app');
      const clear = this.activeApp === appName && this.isCollapsible;
      this.activeApp = clear ? '' : appName;
    } else if (prop === 'activeApp') {
      this.activateApp(!!value);
    }
  }

  triggerTab(element, key) {
    const isElement = element === this.activeTab || this.rootElm === element;

    if (key === 'off-reset' && this.activeApp && isElement) {
      this.restoreTab = this.activeTab;
      this.activeTab = this.activeTab;
    } else if (key === 'off' && this.activeApp && isElement) {
      this.activeTab = this.activeTab;
    } else if (key === 'on-reset' && element !== this.activeTab) {
      this.restoreTab = this.activeTab;
      this.activeTab = element;
    } else if (key === 'on' && (element !== this.activeTab || this.isCollapsible)) {
      this.activeTab = element;
    } else if (key === 'reset' && this.restoreTab) {
      this.activeTab = this.restoreTab;
      this.restoreTab = null;
    }
  }

  activateApp(value) {
    toggleClass(this.outletElm, 'active', value);
    toggleClass(this.activeTab, 'active', value);

    this.crInst.renderModule({
      require: this.activeApp,
      container: this.outletElm,
      context: this.context || 'tab-',
    });
  }

  loadApp(e, elm, item) {
    this.activeTab = e.target;
  }
}));
