require([
  'circular',
  '!app.component.html',
  '!app.component.css',
  'tree-list-helper',
  'data-provider',
  'tree-list',
  'bread-crumb.component',
  'tab-container.component',
],
({ Module }, template, styles, getHelpers, dataProvider) => Module({
  selector: 'body',
  template,
  styles,
  helpers: getHelpers(),
  subscribe$: {
    this: ['isFullScreen', 'isOutlines'],
    pageItems: ['active', 'hovered', 'position', 'isDragging']
  },
}, class AppComponent {
  constructor(elm ,crInst) {
    this.isFullScreen = false;
    this.isOutlines = true;
    this.data = 'tree';
    this.crInst = crInst;
    this.currentHoveredItem = {};
    this.removeEvent = crInst.installEvent(null, 'tree-action', ({ detail }) => {
      if (detail.type === 'active' || detail.type === 'removeChild') { // hand on to subscribe
        crInst.publish(null, 'tree-action', 'change', detail);
      }
    });
    this.pageItems = [];
    dataProvider.getTree(this.data).then(data => {
      this.pageItems = data;
    });
  }

  fullScreen(e, elm, item) {
    this.isFullScreen = !this.isFullScreen;
  }

  toggleOutlines(e, elm, item) {
    this.isOutlines = !this.isOutlines;
  }

  openInNewTab(e, elm, item) {
    console.log('openInNewTab');
  }

  pageItems$$(prop, item, value, oldValue, moved) {
    if (prop.match(/active|selected|hovered/) || prop === 'removeChild') {
      this.crInst.triggerEvent('tree-action', {
        type: prop,
        name: 'page',
        item,
        value,
      });
    }
  }

  click(e, elm, item) {
    item.active = true;
  }
  blur(e, elm, item) {
    item.hovered = false;
  }
  hover(e, elm, item) {
    this.currentHoveredItem.hovered = false;
    item.hovered = true;
    this.currentHoveredItem = item;
  }
  dblClick(e, elm, item) {

  }
  scewStart(e, elm, item) {

  }
  scewEnter(e, elm, item) {

  }
  scewLeave(e, elm, item) {

  }
  scewOver(e, elm, item) {

  }
  scewEnd(e, elm, item) {

  }
  scewDrag(e, elm, item) {

  }
  scewDrop(e, elm, item) {

  }
}));