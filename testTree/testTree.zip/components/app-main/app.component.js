require([
  'circular',
  '!app.component.html',
  '!app.component.css',
  'toolbox',
  'tree-list',
  'bread-crumb.component',
  'tab-container.component',
],
({ Module }, template, styles, $) => Module({
  selector: 'body',
  template,
  styles,
  subscribe$: { this: ['isFullScreen', 'isOutlines'] },
}, class AppComponent {
  constructor() {
    this.isFullScreen = false;
    this.isOutlines = true;
  }

  fullScreen(e, elm, item) {
    this.isFullScreen = !this.isFullScreen;
  }

  toggleOutlines(e, elm, item) {
    this.isOutlines = !this.isOutlines;
  }

  openInNewTab(e, elm, item) {
    console.log('openInNewTab');
  }
}));