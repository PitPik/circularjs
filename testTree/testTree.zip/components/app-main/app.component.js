require([
  'circular',
  '!app.component.html',
  '!app.component.css',
  'tree-list-helper',
  'data-provider',
  'tree-list',
  'bread-crumb.component',
  'tab-container.component',
],
({ Module }, template, styles, getHelpers, dataProvider) => Module({
  selector: 'body',
  template,
  styles,
  helpers: getHelpers(),
  subscribe$: {
    this: ['isFullScreen', 'isOutlines'],
    pageItems: ['active', 'hovered', 'selected', 'position', 'linkClass', 'kind'],
  },
}, class AppComponent {
  constructor(elm ,crInst) {
    this.isFullScreen = false;
    this.isOutlines = true;
    this.data = 'page';
    this.crInst = crInst;
    this.currentHoveredItem = {};
    this.activeItem = {};
    this.removeEvent = crInst.installEvent(null, 'tree-action', ({ detail }) => {
      if (detail.type === 'active' || detail.type === 'removeChild') { // hand on to subscribe
        crInst.publish(null, 'tree-action', 'change', detail);
      }
    });
    this.pageItems = [];
    dataProvider.getTree('tree').then(data => {
      this.pageItems = data;
    });
    this.destroyEvent =
      crInst.installEvent(null, 'tree-action', this.actionListener.bind(this));

    this.noHover = { toggle: false };
    this.revealItem = () => {};
  }

  fullScreen(e, elm, item) {
    this.isFullScreen = !this.isFullScreen;
  }

  toggleOutlines(e, elm, item) {
    this.isOutlines = !this.isOutlines;
  }

  openInNewTab(e, elm, item) {
    console.log('openInNewTab');
  }

  pageItems$(prop, item, value, oldValue) {
    if (value === oldValue) return;
    if (prop === 'active') {
      (this.activeItem || {}).active = false;
      this.activeItem = value ? item : null;
    }
  }

  pageItems$$(prop, item, value, oldValue, moved) {
    if (prop.match(/active|selected|hovered/) || prop === 'removeChild') {
      this.crInst.triggerEvent('tree-action', {
        type: prop,
        name: this.data,
        item,
        value,
      });
    }
  }

  actionListener({ detail }) {
    if (detail.name === this.data) return;
    const item = dataProvider.getItem(detail.item, this.pageItems);
    if (item) {
      item[detail.type] = detail.value;
    } else if (detail.type === 'active' && this.activeItem && this.oneActive) {
      this.activeItem.active = false;
      this.activeItem = null;
    }
  }

  click(e, elm, item) {
    item.active = true;
  }
  blur(e, elm, item) {
    item.hovered = false;
    this.currentHoveredItem = {};
  }
  hover(e, elm, item) {
    this.currentHoveredItem.hovered = false;
    item.hovered = true;
    this.currentHoveredItem = item;
  }
  dblClick(e, elm, item) {

  }
}));