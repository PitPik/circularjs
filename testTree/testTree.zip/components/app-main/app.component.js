require([
  'circular',
  '!app.component.html',
  '!app.component.css',
  'tree-list-helper',
  'tree-list',
  'bread-crumb.component',
  'tab-container.component',
],
({ Module }, template, styles, getHelpers) => Module({
  selector: 'body',
  template,
  styles,
  helpers: getHelpers(),
  subscribe$: { this: ['isFullScreen', 'isOutlines'] },
}, class AppComponent {
  constructor(elm ,crInst) {
    this.isFullScreen = false;
    this.isOutlines = true;
    this.removeEvent = crInst.installEvent(null, 'tree-action', ({ detail }) => {
      if (detail.type === 'active' || detail.type === 'removeChild') { // hand on to subscribe
        crInst.publish(null, 'tree-action', 'change', detail);
      }
    })
  }

  fullScreen(e, elm, item) {
    this.isFullScreen = !this.isFullScreen;
  }

  toggleOutlines(e, elm, item) {
    this.isOutlines = !this.isOutlines;
  }

  openInNewTab(e, elm, item) {
    console.log('openInNewTab');
  }
}));