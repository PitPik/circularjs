require([
  'circular',
  '!app.component.html',
  '!app.component.css',
  'tree-list-helper',
  'data-provider',
  'tree-list',
  'bread-crumb.component',
  'tab-container.component',
],
({ Module }, template, styles, getHelpers, dataProvider) => Module({
  selector: 'body',
  template,
  styles,
  helpers: getHelpers(),
  subscribe$: {
    this: ['isFullScreen', 'isOutlines'],
    pageItems: ['active', 'hovered', 'selected', 'position', 'linkClass', 'kind'],
  },
}, class AppComponent {
  constructor(elm ,crInst) {
    this.isFullScreen = false;
    this.isOutlines = true;
    this.data = 'page';
    this.crInst = crInst;
    this.currentHoveredItem = {};
    this.activeItem = {};
    this.pageItems = [];
    // dummy properties for DnD
    this.noHover = { toggle: false };
    this.revealItem = () => {};

    dataProvider.getTree('tree').then(data => {
      this.pageItems = data;
      dataProvider.registerStore(this.data, this.pageItems);
    });

  }

  fullScreen(e, elm, item) {
    this.isFullScreen = !this.isFullScreen;
  }

  toggleOutlines(e, elm, item) {
    this.isOutlines = !this.isOutlines;
  }

  openInNewTab(e, elm, item) {
    console.log('openInNewTab');
  }

  pageItems$$(prop, item, value, oldValue, moved) {
    dataProvider.syncModel(this.crInst, this.data, prop, item, value, moved);
    if (value === oldValue) return;
    if (prop === 'active') {
      (this.activeItem || {}).active = false;
      this.activeItem = value ? item : null;
    } else if (prop === 'hovered') {
      (this.currentHoveredItem || {}).hovered = false;
      this.currentHoveredItem = value ? item : null;
    }
  }

  click(e, elm, item) {
    item.active = true;
  }

  blur(e, elm, item) {
    item.hovered = false;
  }

  hover(e, elm, item) {
    item.hovered = true;
  }
}));