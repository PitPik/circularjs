define('animate-toggle', ['animate'], (Animate) => {
  Animate.prototype.toggle = function(element, force, speed) {
    const value = element.scrollHeight;
    const isOpen = !force;
    const start = isOpen ? value : 0;
    const end = isOpen ? 0 : value;
    const fn = () => isOpen ? 0 : element.scrollHeight;
    const css = `height: ${start}px -> ${(start < end ? 'fn|fn' : end)}`;
    const needsAnimation = force === undefined ||
      (!isOpen && force) || (isOpen && !force);

    if (needsAnimation) {
      this.queue(element, css, speed, {
        endCallback: elm => force && (elm.style.height = ''),
        updateCallbacks: { fn: fn },
      });
      clearTimeout(this.toggle._timer);
      this.toggle._timer = setTimeout(() => this.resetAnimation(element), 0);
    }
  };

  return Animate;
});
