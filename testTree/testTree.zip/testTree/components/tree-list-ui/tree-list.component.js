require([
  'circular',
  '!tree-list.html',
  '!tree-list.css',
  'tree-list-helper',
  'data-provider',
  'animate-toggle',
  'tree-list-dnd',
  'module-header',
  'tree-list-actions',
  'tool-bar',
], ({ Module }, template, styles, getHelpers, dataProvider, Animate) => Module({
  selector: 'tree-list',
  template,
  styles,
  helpers: getHelpers(),
  subscribe$: {
    tree: ['title', 'isOpen', 'hovered', 'selected', 'active', 'linkClass', 'class'],
  },
}, class TreeList {
  tree = [];
  isOpen = false;
  hasActions = false;
  name = 'the-tree';
  noHover = { toggle: false };
  activeItem = {};
  anim = new Animate({ speed: .3 });

  constructor(elm, crInst, input) {
    input(this);
    dataProvider.getTree(this.name).then(data => {
      this.tree = data;
      if (!data[0].isOpen) {
        this.treeToggle(this.isOpen);
      }
    });
  }

  tree$(prop, item, value, oldValue, internal) {
    if (value === oldValue) return;
    if (prop === 'active') {
      this.activeItem.active = false;
      this.activeItem = item;
    } else if (prop === 'isOpen') {
      dataProvider.storeToggle(item, this.name);
      this.anim.toggle(item.elements.container, value);
    }
    if (value && prop.match(/active|selected|hovered/)) {
      this.openParents(item);
    }
  }

  tree$$(prop, item, type, parent) {
    const parentElm = item.elements.element;
    if (parent['cr-id']) {
      this.anim.animate(parentElm, 'opacity: 0 -> 1', .7, null, n => n * n);
    }
  }

  treeToggle(toggle) {
    const leaveOpen = {};
    let leaf = this.tree.length === 1 && !toggle && this.tree[0] || {};

    while (leaf.childNodes && leaf.childNodes.length === 1) {
      leaveOpen[leaf['cr-id']] = leaf.isOpen = true;
      leaf = leaf.childNodes[0];
    }
    leaf.isOpen = true;
    this.tree.getElementsByProperty('isOpen', !toggle).forEach(item => {
      if (
        leaveOpen[item['cr-id']] === true ||
        leaveOpen[item.parentNode['cr-id']] === true ||
        item.childNodes === undefined ||
        item.childNodes[0] === undefined
      ) return;
      item.isOpen = toggle;
    });
  }

  openParents(item) {
    while (item = item.parentNode) if (!item.isOpen) item.isOpen = true;
  }

  hover(e, elm, item) {
    return e.target === elm && !this.noHover.toggle ?
      item.hovered = true : null;
  }

  blur(e, elm, item) {
    return e.target === elm ? item.hovered = false : null;
  }

  select(e, elm, item) {
    item.active = true;
  }

  toggle(e, elm, item) {
    return item.isOpen = !item.isOpen, false;
  }
}));
