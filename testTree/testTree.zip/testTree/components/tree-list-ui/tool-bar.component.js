require(['circular', '!tool-bar.html', '!tool-bar.css', 'tree-list-helper'],
({ Component }, template, styles, getHelpers) => Component({
  selector: 'tool-bar',
  template,
  styles,
  helpers: getHelpers(['i18n']),
  subscribe$: { this: ['searchValue', 'counter', 'all'] },
}, class ToolBar {
  name = '';
  treeToggle;
  tree = [];

  foundItems = [];
  debounce = 0;
  delay = 300;
  minsearch = 2;
  RegExp = {};
  counter = '';
  all = '';
  searchValue = '';

  constructor(elm, crInst, input) {
    input(this);
  }

  this$(prop) { // TODO: make 'search' its own component
    if (prop !== 'searchValue') return;

    if (!this.all) this.all = this.tree.getElementsByProperty().length;
    clearTimeout(this.debounce);
    if (this.searchValue.length < this.minsearch) {
      this.counter = '';
      return this.mark(this.foundItems, false);
    }

    this.debounce = setTimeout(() => {
      const found = this.getSearchResult(this.searchValue, this.tree);
      const diff = this.foundItems.filter(item => !found.includes(item));
      this.mark(diff, false);
      this.foundItems = this.mark(found, true);
      this.counter = found.length;
    }, this.delay);
  }

  mark(items, toggle) {
    items.forEach(item => {
      item.selected = toggle;
      item.title = !toggle ? item.properties.title :
        item.properties.title.replace(this.RegExp, function(_) {
          [].slice.call(arguments, 1, arguments.length - 2)
            .forEach(finding => _ = _.replace(finding, ($1 => `<b>${$1}</b>`)));
          return _;
        });
    });
    return items;
  }

  getSearchResult(searchValue, treeApi) {
    const txt = searchValue.split(/\s+/).filter(_ => _).join('))(?=.*(');
    this.RegExp = new RegExp(`(?=.*(${txt})).*`, 'i');
    return searchValue === '' ? [] : treeApi
      .getElementsByProperty('properties.title', _ => _.match(this.RegExp));
}

  clear(e) {
    if (e.key === 'Escape') {
      this.searchValue = '';
    }
  }

  input(e) {
    this.searchValue = e.target.value;
  }

  blurInput() {
    this.searchValue = '';
  }

  expand() {
    this.treeToggle(true);
  }

  collapse() {
    this.treeToggle(false);
  }
 }));
